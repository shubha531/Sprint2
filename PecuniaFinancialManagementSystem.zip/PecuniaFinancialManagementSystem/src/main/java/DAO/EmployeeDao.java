package DAO;

import java.util.List;


import Bean.Employee;

public interface EmployeeDao {

	public boolean saveEmployee(Employee employee);
	public List<Employee> getEmployees();
	public boolean deleteEmployee(Employee employee);
	public boolean updateEmployee(Employee employee);
	List<Employee> getEmployeeByID(Employee employee);
}
