package Service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import DAO.EmployeeDao;
import Bean.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
 
	@Autowired
	private EmployeeDao employeedao;
	
	@Override
	public boolean saveEmployee(Employee employee) {
		return employeedao.saveEmployee(employee);
	}

	@Override
	public List<Employee> getEmployee ();  {
		return EmployeeDao .getEmployees ();
	}

	@Override
	public boolean deleteStudent(Student student) {
		return studentdao.deleteStudent(student);
	}

	@Override
	public List<Student> getStudentByID(Student student) {
		return studentdao.getStudentByID(student);
	}

	@Override
	public boolean updateStudent(Student student) {
		return studentdao.updateStudent(student);
	}

	@Override
	public boolean saveEmployee(EmployeeService employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<EmployeeService> getEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteEmployee(EmployeeService employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateEmployee(EmployeeService employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

}
